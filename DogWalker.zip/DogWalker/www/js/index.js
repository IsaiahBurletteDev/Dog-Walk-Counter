let dog;
let time;
let remi = 0;
let valencia = 0;
let timer;
let timev;



function walkEntry() {
    time = prompt("Enter the time you walked a dog");
    dog = prompt("Enter the dog you walked (lowercase) ");
    if(dog === "remi") {
        remi += 1;
        document.getElementById("remi").innerHTML = remi;
        localStorage.setItem(remi + "Remi", time);
        localStorage.setItem("timer", remi);
    }
    else if(dog === "valencia"){
        valencia += 1;
        document.getElementById("valencia").innerHTML = valencia;
        localStorage.setItem(valencia + "Valencia", time);
        localStorage.setItem("timev", valencia);
    }

    
    


}
document.getElementById("remi").innerHTML = remi;

function clearWalks() {
    document.getElementById("remi").innerHTML = 0;
    document.getElementById("valencia").innerHTML = 0;
    localStorage.clear();
}

function getWalks() {
    timer = localStorage.getItem("timer");
    document.getElementById("remi").innerHTML = timer;
    timev = localStorage.getItem("timev");
    document.getElementById("valencia").innerHTML = timev;

    displayTime = prompt("Enter a time you took a dog out ex. 1Remi, 1Valencia");
    timeToDisplay = localStorage.getItem(displayTime);
    document.getElementById("Walks").innerHTML = timeToDisplay;


}